package com.example.myinventoryappneff;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private DatabaseHelper databaseHelper;
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        btnLogin.setOnClickListener(v -> handleLoginButtonClick());
        btnCreateAccount.setOnClickListener(v -> handleCreateAccountButtonClick());
    }

    private void handleLoginButtonClick() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        checkAndRequestSmsPermission();

        if (databaseHelper.checkUser(username, password)) {
            showToast("Login successful");
            navigateToDisplayData();
        } else {
            showToast("Invalid username or password");
        }
    }

    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSms();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }
    private void handleCreateAccountButtonClick() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        try {
            if (databaseHelper.addUser(username, password)) {
                showToast("Account created successfully");
                checkAndRequestSmsPermission();
            } else {
                showToast("Failed to create account");
            }
        } catch (Exception e) {
            showToast("Error creating account: " + e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms();
            } else {
                showToast("SMS permission denied. SMS feature will not work.");
            }
        }
    }

    private void sendSms() {
        String phoneNumber = "6092254776";
        String message = "You Logged Into CartApplication!";

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            showToast("SMS sent successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            showToast("Failed to send SMS.");
        }
    }
    private void navigateToDisplayData() {
        Intent intent = new Intent(MainActivity.this, DisplayDataActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
