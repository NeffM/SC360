package com.example.myinventoryappneff;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        EditText editTextPartNumber = findViewById(R.id.editTextPartNumber);
        EditText editTextQuantity = findViewById(R.id.editTextQuantity);
        EditText editTextPrice = findViewById(R.id.editTextPrice);
        EditText editTextBinLocation = findViewById(R.id.editTextBinLocation);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        databaseHelper = new DatabaseHelper(this);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String partNumber = editTextPartNumber.getText().toString();
                    String quantity = String.valueOf(Integer.parseInt(editTextQuantity.getText().toString()));
                    double price = Double.parseDouble(editTextPrice.getText().toString());
                    String binLocation = editTextBinLocation.getText().toString();
                    if (isValidInput(partNumber, quantity, String.valueOf(price), binLocation)) {
                        Log.d("SaveButton", "Input is valid");
                        if (databaseHelper.addInventoryItem(partNumber, Integer.parseInt(quantity), price, binLocation)) {
                            Log.d("SaveButton", "Item saved successfully");
                            showToast("Item saved successfully");
                            finish();
                        } else {
                            Log.d("SaveButton", "Failed to save item");
                            showToast("Failed to save item");
                        }
                    } else {
                        Log.d("SaveButton", "Invalid input. Please check your entries.");
                        showToast("Invalid input. Please check your entries.");
                    }

                } catch (NumberFormatException e) {
                    Log.d("SaveButton", "Invalid input format. Please enter valid numeric values for quantity and price.");
                    showToast("Invalid input format. Please enter valid numeric values for quantity and price.");
                } finally {
                    Log.d("SaveButton", "Closing database connection");
                    databaseHelper.close();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private boolean isValidInput(String partNumber, String quantity, String price, String binLocation) {
        if (partNumber.isEmpty() || quantity.isEmpty() || price.isEmpty() || binLocation.isEmpty()) {
            showToast("Please fill in all fields");
            return false;
        }

        try {
            int quantityValue = Integer.parseInt(quantity);
            double priceValue = Double.parseDouble(price);

            if (quantityValue < 0 || priceValue < 0) {
                showToast("Quantity and price must be non-negative");
                return false;
            }
        } catch (NumberFormatException e) {
            showToast("Invalid quantity or price");
            return false;
        }

        return true;
    }
}
