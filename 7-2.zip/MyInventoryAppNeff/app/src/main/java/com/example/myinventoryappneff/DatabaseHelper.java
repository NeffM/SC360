package com.example.myinventoryappneff;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user_db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_PART_NUMBER = "part_number";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_BIN_LOCATION = "bin_location";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS +
                    "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_USERNAME + " TEXT," +
                    COLUMN_PASSWORD + " TEXT" +
                    ")";
            db.execSQL(CREATE_USERS_TABLE);
            String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY +
                    "(" +
                    COLUMN_PART_NUMBER + " TEXT PRIMARY KEY," +
                    COLUMN_QUANTITY + " INTEGER," +
                    COLUMN_PRICE + " REAL," +
                    COLUMN_BIN_LOCATION + " TEXT" +
                    ")";
            db.execSQL(CREATE_INVENTORY_TABLE);
        } catch (SQLiteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
            onCreate(db);
        } catch (SQLiteException e) {
            e.printStackTrace();
        }
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        try {
            if (checkUsernameExists(db, username)) {
                return false; // User already exists
            }

            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, password);

            long result = db.insert(TABLE_USERS, null, values);
            return result != -1;
        } catch (SQLiteException e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }
    private boolean checkUsernameExists(SQLiteDatabase db, String username) {
        try {
            String[] columns = {COLUMN_ID};
            String selection = COLUMN_USERNAME + "=?";
            String[] selectionArgs = {username};

            Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            int count = cursor.getCount();
            cursor.close();

            return count > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        try {
            String[] columns = {COLUMN_ID};
            String selection = COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
            String[] selectionArgs = {username, password};

            Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            int count = cursor.getCount();

            return count > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public boolean addInventoryItem(String partNumber, int quantity, double price, String binLocation) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            Log.d("DatabaseHelper", "Trying to insert item into database");
            ContentValues values = new ContentValues();
            values.put(COLUMN_PART_NUMBER, partNumber);
            values.put(COLUMN_QUANTITY, quantity);
            values.put(COLUMN_PRICE, price);
            values.put(COLUMN_BIN_LOCATION, binLocation);

            long result = db.insert(TABLE_INVENTORY, null, values);

            if (result != -1) {
                // Item saved successfully
                Log.d("DatabaseHelper", "Item saved successfully");
                db.close();
                return true;
            } else {
                // Failed to save item
                Log.d("DatabaseHelper", "Failed to save item");
                db.close();
                return false;
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e("DatabaseHelper", "Error inserting item into database: " + e.getMessage());
            db.close();
            return false;
        }
    }



    public ArrayList<String> getInventoryData() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> inventoryData = new ArrayList<>();

        try {
            String[] columns = {COLUMN_PART_NUMBER, COLUMN_QUANTITY, COLUMN_PRICE, COLUMN_BIN_LOCATION};
            Cursor cursor = db.query(TABLE_INVENTORY, columns, null, null, null, null, null);

            while (cursor.moveToNext()) {
                String partNumber = cursor.getString(cursor.getColumnIndex(COLUMN_PART_NUMBER));
                int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY));

                if (quantity < 0) {
                    quantity = 0;
                }

                double price = cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE));
                String binLocation = cursor.getString(cursor.getColumnIndex(COLUMN_BIN_LOCATION));

                String itemData = String.format(Locale.getDefault(),
                        "Part Number: %s, Quantity: %d, Price: $%.2f, Bin Location: %s",
                        partNumber, quantity, price, binLocation);



                inventoryData.add(itemData);
            }

            cursor.close();
            db.close();
        } catch (SQLiteException e) {
            e.printStackTrace();
            db.close();
        }

        return inventoryData;
    }

    public boolean deleteInventoryItem(String partNumber) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            int result = db.delete(TABLE_INVENTORY, COLUMN_PART_NUMBER + "=?", new String[]{partNumber});
            return result > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    public boolean updateInventoryItem(String partNumber, String newDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_QUANTITY, Integer.parseInt(newDetails));  // Assuming you want to update the quantity

        try {
            db.update(TABLE_INVENTORY, contentValues, COLUMN_PART_NUMBER + "=?", new String[]{partNumber});
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }
}