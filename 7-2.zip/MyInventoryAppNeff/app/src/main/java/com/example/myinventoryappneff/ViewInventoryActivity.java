package com.example.myinventoryappneff;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewInventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private InventoryDataAdapter inventoryDataAdapter;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_inventory);

        Button btnCancel = findViewById(R.id.btnCancel);
        GridView inventoryGridView = findViewById(R.id.inventoryGridView);

        databaseHelper = new DatabaseHelper(this);

        try {
            ArrayList<String> inventoryData = databaseHelper.getInventoryData();
            inventoryDataAdapter = new InventoryDataAdapter(this, inventoryData);
            inventoryGridView.setAdapter(inventoryDataAdapter);

        } catch (Exception e) {
            e.printStackTrace();
        }

        inventoryGridView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = inventoryDataAdapter.getItem(position);
            openEditItemActivity(selectedItem);
        });

        inventoryGridView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteInventoryItem(position);
            return true;
        });

        btnCancel.setOnClickListener(v -> finish());
    }
    private void openEditItemActivity(String selectedItem) {
        Intent intent = new Intent(this, EditItemActivity.class);
        intent.putExtra("selectedItem", selectedItem);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
    public class InventoryDataAdapter extends ArrayAdapter<String> {

        public InventoryDataAdapter(Context context, ArrayList<String> items) {
            super(context, R.layout.item_inventory, items);
        }

        @NonNull
        @Override
        public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
            View view = convertView;

            if (view == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                view = inflater.inflate(R.layout.item_inventory, parent, false);
            }

            TextView textViewItem = view.findViewById(R.id.textViewItem);
            textViewItem.setText(getItem(position));

            Button deleteButton = view.findViewById(R.id.buttonDelete);
            deleteButton.setOnClickListener(v -> deleteInventoryItem(position));

            Button editButton = view.findViewById(R.id.buttonEdit);
            editButton.setOnClickListener(v -> editInventoryItem(position));

            return view;
        }

        private void editInventoryItem(int position) {
            String selectedItem = getItem(position);
            openEditItemActivity(selectedItem);
        }
    }
    private void deleteInventoryItem(int position) {
        try {
            String selectedItem = inventoryDataAdapter.getItem(position);
            assert selectedItem != null;
            String[] parts = selectedItem.split(", ");
            String partNumber = parts[0].substring(parts[0].indexOf(":") + 2);

            boolean deleteResult = databaseHelper.deleteInventoryItem(partNumber);

            if (deleteResult) {
                inventoryDataAdapter.remove(selectedItem);
                inventoryDataAdapter.notifyDataSetChanged();

                Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }
}
