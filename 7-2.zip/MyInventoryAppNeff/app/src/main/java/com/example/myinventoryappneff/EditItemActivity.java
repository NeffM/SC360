package com.example.myinventoryappneff;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    private EditText editTextItemDetails;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        Intent intent = getIntent();
        String selectedItem = intent.getStringExtra("selectedItem");

        editTextItemDetails = findViewById(R.id.editTextItemDetails);
        Button btnSaveChanges = findViewById(R.id.btnSaveChanges);

        databaseHelper = new DatabaseHelper(this);
        editTextItemDetails.setText(selectedItem);

        btnSaveChanges.setOnClickListener(view -> saveChanges(selectedItem));
    }

    private void saveChanges(String selectedItem) {
        String editedItemDetails = editTextItemDetails.getText().toString();
        String partNumber = extractPartNumber(selectedItem);

        boolean updateResult = databaseHelper.updateInventoryItem(partNumber, editedItemDetails);

        if (updateResult) {
            showToast("Changes saved successfully");
            finish();
        } else {
            showToast("Failed to save changes");
        }
    }

    private String extractPartNumber(String selectedItem) {
        String[] parts = selectedItem.split(", ");
        return parts[0].substring(parts[0].indexOf(":") + 2);
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
